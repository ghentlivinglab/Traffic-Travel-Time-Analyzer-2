/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iii.vop2016.verkeer2.bean.components;

/**
 *
 * @author Mike
 */
public class DataProvider {
    
    private String name;

    public DataProvider(String name) {
        this.name = name;
    }
    
    
    public String getName() {
        return name;
    }

    
}
