/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iii.vop2016.verkeer2.ejb.helper;

import iii.vop2016.verkeer2.bean.APIKey.APIKey;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.bind.util.JAXBResult;
import javax.xml.namespace.QName;
import javax.xml.transform.Result;

/**
 *
 * @author tobia
 */
public class VerkeerLibToXml {

    public static <T> String toJson(Class<T> clazz, T obj) {
        try {
            JAXBContext jc = JAXBContext.newInstance(clazz);
            JAXBElement<T> je2 = new JAXBElement<>(new QName("APIKey"), clazz, obj);
            Marshaller marshaller = jc.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            Result r =  new JAXBResult(jc);
            marshaller.marshal(je2, r);
            return r.toString();

        } catch (Exception e) {

        }
        return "";
    }

}
