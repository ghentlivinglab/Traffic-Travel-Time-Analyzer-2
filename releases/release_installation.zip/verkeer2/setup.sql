CREATE DATABASE verkeer2;
USE verkeer2;
CREATE USER 'verkeer'@'localhost' IDENTIFIED BY 'vop2016';
GRANT ALL ON verkeer2.* TO 'verkeer'@'localhost';