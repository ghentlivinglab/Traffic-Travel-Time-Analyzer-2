#!/bin/bash
./undeploy.sh
./stop.sh
./start.sh
./deploy.sh
./stop.sh
./start.sh
./deploy.sh
